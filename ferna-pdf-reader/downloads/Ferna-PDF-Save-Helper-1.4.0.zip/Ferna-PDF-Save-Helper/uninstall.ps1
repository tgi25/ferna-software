# Removes the Ferna PDF Reader save helper for the current Windows user.
$HostName = 'com.fernasolutions.pdf_saver'
foreach ($b in 'HKCU:\Software\Google\Chrome\NativeMessagingHosts', 'HKCU:\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts', 'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts', 'HKCU:\Software\Chromium\NativeMessagingHosts') {
  Remove-Item -Path (Join-Path $b $HostName) -Force -ErrorAction SilentlyContinue
}
Remove-Item -Path (Join-Path 'HKCU:\Software\Mozilla\NativeMessagingHosts' $HostName) -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $env:LOCALAPPDATA 'FernaPDF\save-helper') -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'Ferna PDF save helper removed.' -ForegroundColor Green
