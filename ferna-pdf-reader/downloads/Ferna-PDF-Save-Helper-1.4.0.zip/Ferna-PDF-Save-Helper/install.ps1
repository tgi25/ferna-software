# Installs the Ferna PDF Reader save helper for the current Windows user (no administrator rights needed).
# Registers it for Google Chrome, Brave, Microsoft Edge, Chromium and Mozilla Firefox.
$ErrorActionPreference = 'Stop'
$HostName  = 'com.fernasolutions.pdf_saver'
# Chrome/Brave/Edge extension IDs allowed to use the helper: the unpacked (Load unpacked) build, then the store
# builds. Add the Chrome Web Store / Edge Add-ons item IDs here once they are known.
$ExtIds    = @('loopbjkpphjhmppbhioblenkdgmgmldh')
$FirefoxId = 'ferna-pdf-reader@tgifernando'
$Dest      = Join-Path $env:LOCALAPPDATA 'FernaPDF\save-helper'
$Here      = Split-Path -Parent $MyInvocation.MyCommand.Path

New-Item -ItemType Directory -Force -Path $Dest | Out-Null
Copy-Item -LiteralPath (Join-Path $Here 'ferna_pdf_saver.ps1') -Destination $Dest -Force

# Launcher the browser starts (PowerShell script run from a .bat, stdin/stdout passed through)
$launcher = Join-Path $Dest 'ferna_pdf_saver.bat'
Set-Content -LiteralPath $launcher -Encoding ASCII -Value @(
  '@echo off',
  'powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0ferna_pdf_saver.ps1" %*'
)

# Native messaging host manifest
$manifestPath = Join-Path $Dest "$HostName.json"
$manifest = [ordered]@{
  name            = $HostName
  description     = 'Ferna PDF Reader save helper - overwrites PDFs you opened, without a Save dialog'
  path            = $launcher
  type            = 'stdio'
  allowed_origins = @($ExtIds | ForEach-Object { "chrome-extension://$_/" })
}
[IO.File]::WriteAllText($manifestPath, ($manifest | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))

# Firefox reads its own manifest format (allowed_extensions instead of allowed_origins)
$ffManifestPath = Join-Path $Dest "$HostName.firefox.json"
$ffManifest = [ordered]@{
  name               = $HostName
  description        = 'Ferna PDF Reader save helper - opens and overwrites PDFs on your disk, without Save dialogs'
  path               = $launcher
  type               = 'stdio'
  allowed_extensions = @($FirefoxId)
}
[IO.File]::WriteAllText($ffManifestPath, ($ffManifest | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
$ffKey = Join-Path 'HKCU:\Software\Mozilla\NativeMessagingHosts' $HostName
New-Item -Path $ffKey -Force | Out-Null
Set-ItemProperty -Path $ffKey -Name '(default)' -Value $ffManifestPath

$browsers = @(
  'HKCU:\Software\Google\Chrome\NativeMessagingHosts',
  'HKCU:\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts',
  'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts',
  'HKCU:\Software\Chromium\NativeMessagingHosts'
)
foreach ($b in $browsers) {
  $k = Join-Path $b $HostName
  New-Item -Path $k -Force | Out-Null
  Set-ItemProperty -Path $k -Name '(default)' -Value $manifestPath
}

Write-Host ''
Write-Host 'Ferna PDF save helper installed.' -ForegroundColor Green
Write-Host "  Location: $Dest"
Write-Host '  Registered for: Chrome, Brave, Edge, Chromium, Firefox'
Write-Host ''
Write-Host 'Restart your browser. Save (Ctrl+S) in Ferna PDF Reader now overwrites the file directly.'
