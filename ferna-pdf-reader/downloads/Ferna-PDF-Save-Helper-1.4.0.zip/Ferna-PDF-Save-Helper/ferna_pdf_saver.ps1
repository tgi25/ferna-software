# Ferna PDF Reader - save helper (native messaging host for Chrome, Brave, Edge and Firefox)
# Lets the Ferna PDF Reader extension overwrite a PDF you opened from your disk, without a Save dialog.
# In Firefox, which never lets extensions read local files, it also reads PDFs from disk and shows the
# Windows Open / Save As windows.
# Safety rules: only files ending in .pdf, only absolute paths, only files that already exist (overwrite only) -
# except a new file the user has just chosen in this helper's own Save As window - and the browser only lets
# the Ferna extension talk to this helper (allowed_origins / allowed_extensions in the host manifests).
# Protocol: 4-byte little-endian length + UTF-8 JSON, both directions.
#   {cmd:"ping"}                                   -> {ok:true, version}
#   {cmd:"begin", path}                            -> {ok:true}       (starts a temp file next to the target)
#   {cmd:"chunk", data:"<base64>"}                 -> {ok:true}
#   {cmd:"commit", size}                           -> {ok:true, bytes} (atomically replaces the target)
#   {cmd:"abort"}                                  -> {ok:true}
#   {cmd:"read", path, offset, length}             -> {ok:true, size, data:"<base64>"}  (reads part of a .pdf)
#   {cmd:"pickOpen"}                               -> {ok:true, path|null}   (Windows Open window, PDF files)
#   {cmd:"pickSave", name}                         -> {ok:true, path|null}   (Windows Save As window)
$ErrorActionPreference = 'Stop'
$Version = '1.4.0'
$NewAllowed = @{}   # paths chosen in this session's Save As window (may be created)

function Test-PdfPath([string]$p) {
  if (-not [IO.Path]::IsPathRooted($p)) { throw 'Path must be absolute.' }
  if ([IO.Path]::GetExtension($p).ToLowerInvariant() -ne '.pdf') { throw 'Only .pdf files can be used.' }
  return [IO.Path]::GetFullPath($p)
}

function Show-FileDialog([bool]$save, [string]$name) {
  # automated tests only: answer the dialog with a fixed path
  $test = if ($save) { $env:FERNA_HELPER_TEST_SAVE } else { $env:FERNA_HELPER_TEST_OPEN }
  if ($test) { return $test }
  Add-Type -AssemblyName System.Windows.Forms
  $owner = New-Object System.Windows.Forms.Form -Property @{ TopMost = $true; ShowInTaskbar = $false; WindowState = 'Minimized' }
  if ($save) {
    $d = New-Object System.Windows.Forms.SaveFileDialog
    $d.OverwritePrompt = $true
    $d.DefaultExt = 'pdf'; $d.AddExtension = $true
    if ($name) { $d.FileName = [IO.Path]::GetFileName($name) }
  } else {
    $d = New-Object System.Windows.Forms.OpenFileDialog
    $d.CheckFileExists = $true; $d.Multiselect = $false
  }
  $d.Filter = 'PDF documents (*.pdf)|*.pdf'
  $d.Title = if ($save) { 'Ferna PDF Reader - Save As' } else { 'Ferna PDF Reader - Open' }
  try {
    $r = $d.ShowDialog($owner)
    if ($r -eq [System.Windows.Forms.DialogResult]::OK) { return $d.FileName }
    return $null
  } finally { $owner.Dispose() }
}
$stdin = [Console]::OpenStandardInput()
$stdout = [Console]::OpenStandardOutput()

function Read-Exact([int]$count) {
  $buf = New-Object byte[] $count
  $off = 0
  while ($off -lt $count) {
    $n = $stdin.Read($buf, $off, $count - $off)
    if ($n -le 0) { return $null }
    $off += $n
  }
  return ,$buf
}

function Read-Message {
  $lenBuf = Read-Exact 4
  if ($null -eq $lenBuf) { return $null }
  $len = [BitConverter]::ToInt32($lenBuf, 0)
  if ($len -le 0 -or $len -gt 67108864) { return $null }
  $body = Read-Exact $len
  if ($null -eq $body) { return $null }
  return ([Text.Encoding]::UTF8.GetString($body) | ConvertFrom-Json)
}

function Send-Message($obj) {
  $json = $obj | ConvertTo-Json -Compress
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $stdout.Write([BitConverter]::GetBytes([int]$bytes.Length), 0, 4)
  $stdout.Write($bytes, 0, $bytes.Length)
  $stdout.Flush()
}

$target = $null
$tmp = $null
$fs = $null
$written = 0

function Reset-State {
  if ($script:fs) { try { $script:fs.Dispose() } catch {} }
  if ($script:tmp -and (Test-Path -LiteralPath $script:tmp)) { try { Remove-Item -LiteralPath $script:tmp -Force } catch {} }
  $script:fs = $null; $script:tmp = $null; $script:target = $null; $script:written = 0
}

while ($true) {
  $msg = $null
  try { $msg = Read-Message } catch { break }
  if ($null -eq $msg) { break }
  try {
    switch ($msg.cmd) {
      'ping' { Send-Message @{ ok = $true; version = $Version } }
      'begin' {
        Reset-State
        $full = Test-PdfPath ([string]$msg.path)
        $isNew = $msg.create -and $script:NewAllowed.ContainsKey($full.ToLowerInvariant())
        if (-not $isNew -and -not [IO.File]::Exists($full)) { throw "File not found: $full" }
        $script:target = $full
        $script:tmp = $full + '.ferna-' + [Guid]::NewGuid().ToString('N').Substring(0, 8) + '.tmp'
        $script:fs = [IO.File]::Open($script:tmp, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        Send-Message @{ ok = $true }
      }
      'chunk' {
        if (-not $script:fs) { throw 'No save in progress.' }
        $bytes = [Convert]::FromBase64String([string]$msg.data)
        $script:fs.Write($bytes, 0, $bytes.Length)
        $script:written += $bytes.Length
        Send-Message @{ ok = $true }
      }
      'commit' {
        if (-not $script:fs) { throw 'No save in progress.' }
        $script:fs.Flush($true); $script:fs.Dispose(); $script:fs = $null
        if ($msg.size -and [int64]$msg.size -ne [int64]$script:written) { throw "Size mismatch ($($script:written) of $($msg.size) bytes)." }
        if (-not [IO.File]::Exists($script:target)) {
          # a new file chosen in the Save As window
          [IO.File]::Move($script:tmp, $script:target)
        } else {
          $attrs = [IO.File]::GetAttributes($script:target)
          if ($attrs -band [IO.FileAttributes]::ReadOnly) { throw 'The file is read-only.' }
          try {
            [IO.File]::Replace($script:tmp, $script:target, $null)
          } catch {
            # e.g. some network drives: fall back to copy-over
            [IO.File]::Copy($script:tmp, $script:target, $true)
            Remove-Item -LiteralPath $script:tmp -Force
          }
        }
        $n = $script:written
        $script:tmp = $null; $script:target = $null; $script:written = 0
        Send-Message @{ ok = $true; bytes = $n }
      }
      'abort' { Reset-State; Send-Message @{ ok = $true } }
      'read' {
        $full = Test-PdfPath ([string]$msg.path)
        if (-not [IO.File]::Exists($full)) { throw "File not found: $full" }
        $offset = [int64]$msg.offset
        $length = [int]$msg.length
        if ($length -le 0 -or $length -gt 700000) { $length = 524288 }
        $rs = [IO.File]::Open($full, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
        try {
          $size = $rs.Length
          $buf = New-Object byte[] ([int][Math]::Max(0, [Math]::Min([int64]$length, $size - $offset)))
          if ($buf.Length -gt 0) {
            [void]$rs.Seek($offset, [IO.SeekOrigin]::Begin)
            $got = 0
            while ($got -lt $buf.Length) { $n = $rs.Read($buf, $got, $buf.Length - $got); if ($n -le 0) { break }; $got += $n }
          }
        } finally { $rs.Dispose() }
        Send-Message @{ ok = $true; size = $size; data = [Convert]::ToBase64String($buf) }
      }
      'pickOpen' {
        $p = Show-FileDialog $false ''
        if ($p) { $p = Test-PdfPath $p }
        Send-Message @{ ok = $true; path = $p }
      }
      'pickSave' {
        $p = Show-FileDialog $true ([string]$msg.name)
        if ($p) {
          if ([IO.Path]::GetExtension($p).ToLowerInvariant() -ne '.pdf') { $p = $p + '.pdf' }
          $p = Test-PdfPath $p
          $script:NewAllowed[$p.ToLowerInvariant()] = $true
        }
        Send-Message @{ ok = $true; path = $p }
      }
      default { Send-Message @{ ok = $false; error = "Unknown command: $($msg.cmd)" } }
    }
  } catch {
    $err = $_.Exception.Message
    if ($msg.cmd -ne 'ping') { Reset-State }
    Send-Message @{ ok = $false; error = $err }
  }
}
Reset-State
